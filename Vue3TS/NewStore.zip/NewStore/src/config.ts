// 或分开声明与导出
const TOKEN_KEY = 'token';
export { TOKEN_KEY };
